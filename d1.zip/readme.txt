remove order creation system
add 2 gateway 1 automatic 1 manual
add withdraw waggering condition